//---------------------------------------------------------------------------

#pragma hdrstop

#include "pomocna.h"
#include <iostream>
#include <algorithm>

bool operator<(Tacka A, Tacka B){
	if(A.x < B.x){
		return true;
	}
	else if(A.x > B.x){
		return false;
	}
	else return A.y < B.y;
}

bool operator==(Tacka A, Tacka B){
	return A.x == B.x && A.y == B.y;
}

void Tacka::Crtaj(TImage* Slika){
	int n = 3;
	Slika->Canvas->Brush->Color = clRed;
	Slika->Canvas->Ellipse(x-n,y-n,x+n,y+n);
	Slika->Canvas->Brush->Color = clWhite;
}

void Duz::Crtaj(TImage* Slika){
	Slika->Canvas->Pen->Color = clBlue;
	Slika->Canvas->MoveTo(A.x,A.y);
	Slika->Canvas->LineTo(B.x,B.y);
	Slika->Canvas->Pen->Color = clBlack;
}

void Pravougaonik::Crtaj(TImage* Slika) {
    Slika->Canvas->Pen->Color = clBlue;
	Slika->Canvas->Rectangle(A.x, A.y, B.x, B.y);
	Slika->Canvas->Pen->Color = clBlack;
}

int Orijentacija(Tacka A, Tacka B, Tacka C){
	int povrsina = A.x * (B.y - C.y) + B.x * (C.y - A.y) + C.x * (A.y-B.y);
	if(povrsina > 0){
		return -1;
	}
	else if(povrsina < 0){
		return 1;
	}
	else return 0;
}

bool daLiSeDuziSijeku(Duz d1, Duz d2){
	bool uslov1 = Orijentacija(d1.A,d1.B,d2.A) != Orijentacija(d1.A,d1.B,d2.B);
	bool uslov2 = Orijentacija(d2.A,d2.B,d1.A) != Orijentacija(d2.A,d2.B,d1.B);
	return uslov1 && uslov2;
}

bool daLiJeTackaUTrouglu(Tacka T, Trougao tr){
	int uslov1 = Orijentacija(tr.A, tr.B,T);
	int uslov2 = Orijentacija(tr.B,tr.C, T);
	int uslov3 = Orijentacija(tr.C,tr.A,T);
	return (uslov1 == uslov2) && (uslov2 == uslov3);
}

void iscrtajPoligon(vector<Tacka>&tacke, TImage* Slika){
	Slika->Canvas->Pen->Color = clBlue;
	Slika->Canvas->MoveTo(tacke[0].x, tacke[0].y);
	for(int i = 1; i < tacke.size(); i++){
		Slika->Canvas->LineTo(tacke[i].x, tacke[i].y);
	}
	Slika->Canvas->LineTo(tacke[0].x, tacke[0].y);
	Slika->Canvas->Pen->Color = clBlack;
}



int izracunajPovrsinuPresjeka(Pravougaonik& p1, Pravougaonik& p2){
//koordinate gdje se sjeku, ako se sjeku.
	int x1 = max(p1.A.x, p2.A.x);//vea x koordinata od pocetnih lijevih
	int y1 = max(p1.A.y, p2.A.y);//veca y koordinata od pocetnih lijevih
	int x2 = min(p1.B.x, p2.B.x);//manja od krajnjih desnih
	int y2 = min(p1.B.y, p2.B.y);//manja od gornjih lijevih

	//provjeti da li ima presjeka, ako nema vrati 0
	if (x1 >= x2 || y1 >= y2) {
		return 0;
    }

	// Racunaj presjek jer ga ima jer je prosao gore
	int sirina = x2 - x1;
	int visina = y2 - y1;
	return visina * sirina;
}

int izracunajZapreminuUnije(vector<Pravougaonik> pravougaonici1){
	int povrsina = 0;

	for (int i = 0; i < pravougaonici1.size(); i++) {
		int p = pravougaonici1[i].duzina() * pravougaonici1[i].visina();
		povrsina += p;

		for (int j = i + 1; j < pravougaonici1.size(); j++) { //Ovo je razlog kvadratnog vremena
			int ppresjeka = izracunajPovrsinuPresjeka(pravougaonici1[i], pravougaonici1[j]);
			povrsina -= ppresjeka;
        }
	}
	return povrsina;
}


//povrsina sveeping line kvadratno vrijeme:
int povrsina_unije_sweeping_line(Event events_v[],Event events_h[],int n,int e){
	//n broj pravougaonika, e broj tacaka, tj 2*n
	bool in_set[MAX]={0};
	int area=0;
	sort(events_v, events_v+e, compare_x);  //Sortiramo vertikalno
	sort(events_h, events_h+e, compare_y); // Sortiramo horizontalno
	in_set[events_v[0].ind] = 1;
        for (int i=1;i<e;++i)
		{ // Vertikalni sweep line
			  Event c = events_v[i];
			  int cnt = 0; // Brojac trenutno preklapajucih pravougaonika
				// Delta_x: Udaljenost sweeping linija trenutne i prethodne
				int delta_x = rects[c.ind][c.type].x - rects[events_v[i-1].ind][events_v[i-1].type].x;
                int begin_y;
                if (delta_x==0){
                        in_set[c.ind] = (c.type==0);
                        continue;
                }
				for (int j=0;j<e;++j)
						if (in_set[events_h[j].ind]==1) //Horizontalni sweep line za aktivni pravougaonik
						{
								if (events_h[j].type==0)//donja ivica pravougaonika
								{
										if (cnt==0) begin_y = rects[events_h[j].ind][0].y;
										++cnt;//Povecava se preklapajuci broj pravougaonika
								}
								else //gornja ivica
								{
										--cnt;//onda se vise ne preklapaju
										if (cnt==0)
                                        {
												int delta_y = (rects[events_h[j].ind][13].y-begin_y);//Duzina vertikale koja sjece pravougaonike
												area+=delta_x * delta_y;
                                        }
								}
						}
				in_set[c.ind] = (c.type==0);//ako je lijeva ivica pravougaonik je aktivan inace nije
		}
    return area;

}

#pragma package(smart_init)
