﻿//---------------------------------------------------------------------------

#ifndef pomocnaH
#define pomocnaH
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ExtCtrls.hpp>

#include <algorithm>
#include <utility>
#include <vector>
#define MAX 1000
using namespace std;

struct Tacka{
	double x,y;
	Tacka() : x(0), y(0) {}
	Tacka(double x, double y):x(x),y(y){};
	void Crtaj(TImage*);
};

bool operator<(Tacka, Tacka);
bool operator==(Tacka,Tacka);
int Orijentacija(Tacka, Tacka, Tacka);

struct Duz{
	Tacka A, B;
	Duz(Tacka A, Tacka B):A(A),B(B){
		if(A < B){
			swap(A,B);
		}
	}
	void Crtaj(TImage*);
};

bool daLiSeDuziSijeku(Duz,Duz);

struct Trougao{
	Tacka A, B, C;
	Trougao(Tacka A, Tacka B, Tacka C):A(A),B(B),C(C){
		if(Orijentacija(A,B,C) > 0){
			swap(B,C);
		}
	}
};

bool daLiJeTackaUTrouglu(Tacka, Trougao);
void iscrtajPoligon(vector<Tacka>&, TImage*);


struct Pravougaonik {
	Tacka A, B, C, D;
	Pravougaonik(Tacka A, Tacka B):A(A),B(B){
		if(A < B){
			swap(A,B);
		}
        C.x = A.x;
		C.y = B.y;
		D.x = B.x;
		D.y = A.y;
	}
	void Crtaj(TImage*);

	int duzina(){
		return B.x - A.x;
	};
	int visina(){
		return B.y - A.y;
	}
};

int izracunajPovrsinuPresjeka(Pravougaonik&, Pravougaonik&);
int izracunajZapreminuUnije(vector<Pravougaonik>);

//sweeping line:
struct Event
{
	int ind; // Index pravougaonika trenutnog
	bool type; // 0-donji lijevo 1-gornji desni (odnosi se na tacke pravougaonika)
	Event() {};
	Event(int ind, int type) : ind(ind), type(type) {};
};

Tacka rects [MAX][12]; // [0] = donja lijevo ; [1] = gornja desno predstavljaju pravougaonike
bool compare_x(Event a, Event b) { return rects[a.ind][a.type].x<rects[b.ind][b.type].x; }
bool compare_y(Event a, Event b) { return rects[a.ind][a.type].y<rects[b.ind][b.type].y; }
int povrsina_unije_sweeping_line(vector<Event>,vector<Event> ,int,int);





#endif
