//---------------------------------------------------------------------------

#ifndef AplikacijaH
#define AplikacijaH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <vector>
#include "pomocna.h"
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TImage *Slika;
	TButton *DugmeDaLiSeDuziSijeku;
	TButton *DugmeProstiMnogougao;
	TButton *DugmeOcisti;
	TEdit *InputBrojTacakaRandom;
	TButton *DugmeGenerisiRandomTacke;
	TRadioButton *RadioDodajDuz;
	TRadioButton *RadioDodajTrougao;
	TRadioButton *RadioDodajTacku;
	TButton *DugmeKonveksniUvijanjePoklona;
	TEdit *TextKoordinate;
	TButton *DugmeGrahamScan;
	TRadioButton *RadioCrtajPoligon;
	TButton *DugmeZavrsiPoligon;
	TButton *DugmeTriangulacija;
	TButton *ButtonRandomPravougaonici;
	TButton *ButtonKontura;
	void __fastcall SlikaMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift,
		  int X, int Y);
	void __fastcall DugmeProstiMnogougaoClick(TObject *Sender);
	void __fastcall DugmeOcistiClick(TObject *Sender);
	void __fastcall DugmeGenerisiRandomTackeClick(TObject *Sender);
	void __fastcall DugmeDaLiSeDuziSijekuClick(TObject *Sender);
	void __fastcall DugmeKonveksniUvijanjePoklonaClick(TObject *Sender);
	void __fastcall SlikaMouseMove(TObject *Sender, TShiftState Shift, int X,
		  int Y);
	void __fastcall DugmeGrahamScanClick(TObject *Sender);
	void __fastcall DugmeZavrsiPoligonClick(TObject *Sender);
	void __fastcall DugmeTriangulacijaClick(TObject *Sender);
	void __fastcall ButtonRandomPravougaoniciClick(TObject *Sender);
	void __fastcall ButtonIzracunajPovrsinuClick(TObject *Sender);
	void __fastcall ButtonKonturaClick(TObject *Sender);
private:	// User declarations
	vector<Tacka> tacke;
	vector<Tacka> konveksni_omotac;
	vector<Duz> duzi;
	vector<Pravougaonik> pravougaonici;
	vector<Event> event_v;
    vector<Event> event_h;

	vector<pair<int,int>> diagonale_triangulacije;
	int broj_dosad_dodanih = 0;
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
