//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Aplikacija.h"
#include <algorithm>
#include "pomocna.h"
#include <string>
#include <list>
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
	Slika ->Canvas->Brush->Color = clWhite;
	Slika->Canvas->FillRect(Rect(0,0,Slika->Width, Slika->Height));

	Slika ->Canvas->Brush->Color = clBlack;
	Slika->Canvas->FrameRect(Rect(0,0,Slika->Width, Slika->Height));
	Slika ->Canvas->Brush->Color = clWhite;
	RadioDodajTacku->Checked = true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SlikaMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift,
          int X, int Y)
{
	Tacka nova(X,Y);
	if(RadioDodajTacku -> Checked){
		tacke.push_back(nova);
		nova.Crtaj(Slika);
	}
	else if(RadioDodajDuz->Checked){
		broj_dosad_dodanih++;
		if(broj_dosad_dodanih == 2){
			broj_dosad_dodanih = 0;
			duzi.push_back(Duz(tacke[tacke.size() -1], nova));
			duzi[duzi.size() -1].Crtaj(Slika);
		}
		tacke.push_back(nova);
		nova.Crtaj(Slika);
	}
	else if(RadioCrtajPoligon -> Checked){
		tacke.push_back(nova);
		if(tacke.size() > 1){
			Duz(tacke[tacke.size()-2],nova).Crtaj(Slika);
		}
		nova.Crtaj(Slika);
	}
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DugmeProstiMnogougaoClick(TObject *Sender)
{
	for(int i = 0; i < tacke.size(); i++){
		if(tacke[i] < tacke[0])
			swap(tacke[0],tacke[i]);      //Tacke[0] uvijek je najmanja tacka od svih!
	}
	Tacka lijeva(tacke[0]);
	sort(tacke.begin()+1,tacke.end(),[lijeva](Tacka A, Tacka B){ return Orijentacija(lijeva, A, B)<0; });
	iscrtajPoligon(tacke,Slika);
}



//---------------------------------------------------------------------------
void __fastcall TForm1::DugmeOcistiClick(TObject *Sender)
{
	Slika ->Canvas->Brush->Color = clWhite;
	Slika->Canvas->FillRect(Rect(0,0,Slika->Width, Slika->Height));
    Slika ->Canvas->Brush->Color = clBlack;
	Slika->Canvas->FrameRect(Rect(0,0,Slika->Width, Slika->Height));
	Slika ->Canvas->Brush->Color = clWhite;
	tacke.clear();
	duzi.clear();
	pravougaonici.clear();
	konveksni_omotac.clear();
	diagonale_triangulacije.clear();
	broj_dosad_dodanih = 0;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DugmeGenerisiRandomTackeClick(TObject *Sender)
{
	int broj_tacaka = InputBrojTacakaRandom->Text.ToInt();
	for(int i = 0; i < broj_tacaka; i++){
		tacke.push_back(Tacka(rand() % Slika->Width, rand() % Slika->Height));
		tacke[tacke.size() - 1].Crtaj(Slika);
	}

}
//---------------------------------------------------------------------------
void __fastcall TForm1::DugmeDaLiSeDuziSijekuClick(TObject *Sender)
{
	if(duzi.size() < 2){
		return;
	}
	Duz d1(duzi[duzi.size() - 1]), d2(duzi[duzi.size()-2]);
	bool sijeku_se = daLiSeDuziSijeku(d1,d2);
	if(sijeku_se){
		ShowMessage("Duzi se sijeku!");
	}
	else{
		ShowMessage("Duzi se ne sijeku!");
	}
}
//---------------------------------------------------------------------------



void __fastcall TForm1::DugmeKonveksniUvijanjePoklonaClick(TObject *Sender)
{
	if(tacke.size() < 3){
		return;
	}

    for(int i = 0; i < tacke.size(); i++){
		if(tacke[i] < tacke[0])
			swap(tacke[0],tacke[i]);      //Tacke[0] uvijek je najmanja tacka od svih!
	}
	Tacka lijeva(tacke[0]);
	konveksni_omotac.push_back(lijeva);
	while(true){
		Tacka zadnja = konveksni_omotac[konveksni_omotac.size()-1];
		int indeks_iduce = 0;

		if(tacke[indeks_iduce] == zadnja){
			indeks_iduce = 1;
		}

		for(int i = 1; i < tacke.size(); i++){
			if(tacke[i] == zadnja)
				continue;
			if(Orijentacija(zadnja,tacke[indeks_iduce],tacke[i]) > 0){
				indeks_iduce = i;
			}
		}
		Tacka iduca = tacke[indeks_iduce];
		if(iduca == lijeva)
			break;
		konveksni_omotac.push_back(iduca);
	}
	iscrtajPoligon(konveksni_omotac, Slika);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::SlikaMouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y)
{
	string koordinate = "X: " + to_string(X) + " Y: " + to_string(Y);
	TextKoordinate->Text = koordinate.c_str();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::DugmeGrahamScanClick(TObject *Sender)
{
    for(int i = 0; i < tacke.size(); i++){
		if(tacke[i] < tacke[0])
			swap(tacke[0],tacke[i]);      //Tacke[0] uvijek je najmanja tacka od svih!
	}
	Tacka lijeva(tacke[0]);
	sort(tacke.begin()+1,tacke.end(),[lijeva](Tacka A, Tacka B){ return Orijentacija(lijeva, A, B)<0; });

	konveksni_omotac.push_back(lijeva);
	konveksni_omotac.push_back(tacke[1]);

	for(int i = 2; i < tacke.size(); i++){
		Tacka predzadnja(konveksni_omotac[konveksni_omotac.size()-2]);
		Tacka zadnja(konveksni_omotac[konveksni_omotac.size()-1]);
		Tacka trenutna(tacke[i]);
		while(Orijentacija(predzadnja,zadnja,trenutna) > 0){
			konveksni_omotac.pop_back();
			predzadnja = konveksni_omotac[konveksni_omotac.size()-2];
			zadnja = konveksni_omotac[konveksni_omotac.size()-1];
		}
		konveksni_omotac.push_back(trenutna);
	}

	iscrtajPoligon(konveksni_omotac,Slika);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::DugmeZavrsiPoligonClick(TObject *Sender)
{
	int n(tacke.size());
	if(n < 3)
		return;
	Duz(tacke[0],tacke[n-1]).Crtaj(Slika);
}
//---------------------------------------------------------------------------

template <typename TipLista>
void pomjeriIteratorNaprijed(typename TipLista::iterator &it, TipLista &lista){
	it++;
	if(it == lista.end())
		it = lista.begin();
}

template <typename TipLista>
void pomjeriIteratorNazad(typename TipLista::iterator &it, TipLista &lista){
	if(it == lista.begin())
		it = lista.end();
	it--;
}

void __fastcall TForm1::DugmeTriangulacijaClick(TObject *Sender)
{
	list<int> lista_tacaka;
	for(int i = 0; i < tacke.size(); i++){
		lista_tacaka.push_back(i);
	}
	auto trenutni = lista_tacaka.begin();
	auto prethodni = trenutni;
	pomjeriIteratorNazad<list<int>>(prethodni,lista_tacaka);
	auto naredni = trenutni;
	pomjeriIteratorNaprijed<list<int>>(naredni,lista_tacaka);

	while(lista_tacaka.size() > 3){
		if(Orijentacija(tacke[*prethodni],tacke[*trenutni],tacke[*naredni]) < 0){
			//potencijalno uho
			auto provjera(naredni);
			Trougao t(tacke[*prethodni],tacke[*trenutni],tacke[*naredni]);
			pomjeriIteratorNaprijed<list<int>>(provjera,lista_tacaka);
			bool uho(true);
			while(provjera != prethodni){
				if(daLiJeTackaUTrouglu(tacke[*provjera],t)){
					uho = false;
					break;
				}
                pomjeriIteratorNaprijed<list<int>>(provjera,lista_tacaka);
			}
			if(uho){
				diagonale_triangulacije.push_back({*prethodni,*naredni});
				lista_tacaka.erase(trenutni);
				trenutni = prethodni;
				pomjeriIteratorNazad<list<int>>(prethodni,lista_tacaka);
				continue;
			}
		}
		prethodni = trenutni;
		trenutni = naredni;
		pomjeriIteratorNaprijed<list<int>>(naredni,lista_tacaka);
	}

	for(auto &par_indeksa:diagonale_triangulacije){
		Duz(tacke[par_indeksa.first],tacke[par_indeksa.second]).Crtaj(Slika);
	}
}
//---------------------------------------------------------------------------




void __fastcall TForm1::ButtonRandomPravougaoniciClick(TObject *Sender)
{
	int broj_duzi = InputBrojTacakaRandom->Text.ToInt();

for(int i = 0; i < broj_duzi; i++) {
	int x1 = rand() % Slika->Width;
	int y1 = rand() % Slika->Height;
	int x2 = rand() % Slika->Width;
	int y2 = rand() % Slika->Height;

	int lijeva_granica = min(x1, x2);
	int desna_granica = max(x1, x2);
	int gornja_granica = min(y1, y2);
	int donja_granica = max(y1, y2);

	Tacka lijeva_dole = Tacka(lijeva_granica, donja_granica);
	Tacka desna_gore = Tacka(desna_granica, gornja_granica);

	pravougaonici.push_back(Pravougaonik(lijeva_dole,desna_gore));
	event_h.push_back(Event(i,0)); //punimo eventh i eventv tackama
	event_v.push_back(Event(i,1));

		for(int j = 0; j < pravougaonici.size(); j++) {
			pravougaonici[j].A.Crtaj(Slika);
			pravougaonici[j].B.Crtaj(Slika);
			pravougaonici[j].Crtaj(Slika);
		}
	}
}
//---------------------------------------------------------------------------




void __fastcall TForm1::ButtonIzracunajPovrsinuClick(TObject *Sender)
{
	int k = izracunajZapreminuUnije(pravougaonici);
	k = k*(-1);
	std::wstring message = L"Povrsina je: " + std::to_wstring(k);
	Application->MessageBoxW(message.c_str(), L"Variable Value", MB_OK);

	//int sw = povrsina_unije_sweeping_line(event_v, event_h,pravougaonici.size(), 2*pravougaonici.size());
	//std::wstring message1 = L"Povrsina sa sweeping line je: " + std::to_wstring(sw);
	//Application->MessageBoxW(message1.c_str(), L"Variable Value", MB_OK);

}
//---------------------------------------------------------------------------

void __fastcall TForm1::ButtonKonturaClick(TObject *Sender)
{
	if (pravougaonici.empty())
		return;

	// Koordinate svih vrhova
    vector<int> xCoords, yCoords;
	for (const Pravougaonik& pravougaonik : pravougaonici) {
		xCoords.push_back(pravougaonik.A.x);
		xCoords.push_back(pravougaonik.B.x);
		yCoords.push_back(pravougaonik.A.y);
		yCoords.push_back(pravougaonik.B.y);
    }

	// box unije pravougaonika
	int minX = *min_element(xCoords.begin(), xCoords.end());
    int maxX = *max_element(xCoords.begin(), xCoords.end());
    int minY = *min_element(yCoords.begin(), yCoords.end());
    int maxY = *max_element(yCoords.begin(), yCoords.end());

	// Crtam konturu
	Pravougaonik p(Tacka(minX, minY), Tacka(maxX, maxY));
	p.Crtaj(Slika);

}
//---------------------------------------------------------------------------

